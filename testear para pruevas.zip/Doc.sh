sudo -i
 echo > /etc/apache2/sites-available/prueva.conf

echo -e "<VirtualHost *:80>\v" >>/etc/apache2/sites-available/prueva.conf
INTENTO CREAR EN ARCHIVO DIRECTAMENTE POR QUE ME PARECE MAS FACIL ASI SI NO 
COPIO EL INDEX Y SUS CARPETAS A /var/www/html PARA QUE SE HABRA DE LOCAL HOST 
